import React from "react";
import styled from "styled-components";

const Container = styled.div`
  padding: 2rem;
  max-width: 800px;
  margin: 0 auto;
`;

const Header = styled.header`
  text-align: center;
  font-size: 1.5rem;
  margin-bottom: 1rem;
`;

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <Container>
    <Header>CRUD App</Header>
    {children}
  </Container>
);

export default Layout;
