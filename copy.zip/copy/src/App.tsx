import React from "react";
import { QueryClient, QueryClientProvider } from "react-query";
import Layout from "./components/Layout";
import Home from "./pages/Home";

const queryClient = new QueryClient();

const App: React.FC = () => (
  <QueryClientProvider client={queryClient}>
    <Layout>
      <Home />
    </Layout>
  </QueryClientProvider>
);

export default App;
