import apiClient from './apiClient';
import axios from 'axios';

export interface User {
  id: number;
  name: string;
  email: string;
}

export const fetchUsers = async (): Promise<User[]> => {
  const { data } = await apiClient.get('/users');
  return data;
};

export const createUser = async (user: Partial<User>): Promise<User> => {
  const { data } = await apiClient.post('/users', user);
  return data;
};

export const updateUser = async (id: number, user: Partial<User>): Promise<User> => {
  const { data } = await apiClient.put(`/users/${id}`, user);
  return data;
};

export const deleteUser = async (id: number): Promise<void> => {
  await apiClient.delete(`/users/${id}`);
};

// export const deleteUser = async (id: number): Promise<void> => {
//   await axios.delete(`/api/users/${id}`);
// };