// import React, { useState } from "react";
// import { useQuery, useMutation, useQueryClient } from "react-query";
// import { fetchUsers, deleteUser } from "../api/Users";
// import { User } from "../types";
// import styled from "styled-components";
// import Modal from "../components/Modal";
// import CreateEditForm from "./CreateEditForm";

// const Table = styled.table`
//   width: 100%;
//   border-collapse: collapse;
//   margin-top: 1rem;

//   th,
//   td {
//     border: 1px solid #ddd;
//     padding: 8px;
//     text-align: left;
//   }

//   th {
//     background: #f4f4f4;
//   }
// `;

// const Home: React.FC = () => {
//   const queryClient = useQueryClient();
//   const [selectedUser, setSelectedUser] = useState<User | null>(null);
//   const [isModalOpen, setIsModalOpen] = useState(false);

//   const { data: users, isLoading, error } = useQuery("users", fetchUsers);
//   const deleteMutation = useMutation(deleteUser, {
//     onSuccess: () => queryClient.invalidateQueries("users"),
//   });

//   const handleDelete = (id: number) => {
//     if (window.confirm("Are you sure you want to delete this user?")) {
//       deleteMutation.mutate(id);
//     }
//   };

//   const handleEdit = (user: User) => {
//     setSelectedUser(user);
//     setIsModalOpen(true);
//   };

//   if (isLoading) return <div>Loading...</div>;
//   if (error) return <div>Error loading users</div>;

//   return (
//     <>
//       <button onClick={() => setIsModalOpen(true)}>Add User</button>
//       <Table>
//         <thead>
//           <tr>
//             <th>Name</th>
//             <th>Email</th>
//             <th>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {users?.map((user) => (
//             <tr key={user.id}>
//               <td>{user.name}</td>
//               <td>{user.email}</td>
//               <td>
//                 <button onClick={() => handleEdit(user)}>Edit</button>
//                 <button onClick={() => handleDelete(user.id)}>Delete</button>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </Table>

//       {isModalOpen && (
//         <Modal onClose={() => setIsModalOpen(false)}>
//           <CreateEditForm
//             user={selectedUser}
//             onClose={() => setIsModalOpen(false)}
//           />
//         </Modal>
//       )}
//     </>
//   );
// };

// export default Home;

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "react-query";
import styled from "styled-components";
import { fetchUsers, deleteUser, User } from "../api/Users";
import CreateEditForm from "./CreateEditForm";

const Container = styled.div`
  padding: 20px;
`;

const UserList = styled.div`
  margin-top: 20px;
`;

const UserItem = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 10px;
  border: 1px solid #ccc;
  margin-bottom: 10px;
  border-radius: 4px;
`;

const Button = styled.button`
  margin-left: 10px;
  padding: 5px 10px;
  border: none;
  background-color: #007bff;
  color: white;
  border-radius: 4px;
  cursor: pointer;

  &:hover {
    background-color: #0056b3;
  }

  &.delete {
    background-color: #dc3545;

    &:hover {
      background-color: #a71d2a;
    }
  }
`;

const Home: React.FC = () => {
  const queryClient = useQueryClient();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showForm, setShowForm] = useState(false);

  // Fetch users with a staleTime to prevent unnecessary refetches
  const {
    data: users,
    isLoading,
    error,
  } = useQuery<User[]>("users", fetchUsers, {
    staleTime: 5 * 60 * 1000, // Cache is fresh for 5 minutes
    refetchOnWindowFocus: false, // Disable refetch on window focus
  });

  // Delete user mutation
  const deleteMutation = useMutation(
    (id: number) => deleteUser(id), // API call
    {
      onSuccess: (_, id) => {
        // Optimistically update cache to remove the deleted user
        queryClient.setQueryData<User[]>("users", (oldUsers) =>
          oldUsers ? oldUsers.filter((user) => user.id !== id) : []
        );
      },
      onError: (error) => {
        console.error("Failed to delete user:", error);
        alert("Failed to delete user. Please try again.");
      },
    }
  );

  // Function to handle delete
  const handleDelete = (id: number) => {
    if (window.confirm("Are you sure you want to delete this user?")) {
      deleteMutation.mutate(id); // Trigger the mutation
    }
  };

  // Handle edit
  const handleEdit = (user: User) => {
    setSelectedUser(user);
    setShowForm(true);
  };

  // Handle create
  const handleCreate = () => {
    setSelectedUser(null);
    setShowForm(true);
  };

  // Close form
  const handleCloseForm = () => {
    setShowForm(false);
  };

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error loading users</div>;

  return (
    <Container>
      <h1>User Management</h1>
      <Button onClick={handleCreate}>Create User</Button>

      {showForm && (
        <CreateEditForm user={selectedUser} onClose={handleCloseForm} />
      )}

      <UserList>
        {users?.map((user) => (
          <UserItem key={user.id}>
            <div>
              <strong>{user.name}</strong> - {user.email}
            </div>
            <div>
              <Button onClick={() => handleEdit(user)}>Edit</Button>
              <Button className="delete" onClick={() => handleDelete(user.id)}>
                Delete
              </Button>
            </div>
          </UserItem>
        ))}
      </UserList>
    </Container>
  );
};

export default Home;
