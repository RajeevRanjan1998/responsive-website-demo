// import React from "react";
// import { useForm } from "react-hook-form";
// import { useMutation, useQueryClient } from "react-query";
// import { createUser, updateUser, User } from "../api/Users";

// interface FormProps {
//   user?: User | null;
//   onClose: () => void;
// }

// const CreateEditForm: React.FC<FormProps> = ({ user, onClose }) => {
//   const { register, handleSubmit } = useForm<User>({
//     defaultValues: user || { name: "", email: "" },
//   });

//   const queryClient = useQueryClient();
//   const createMutation = useMutation(createUser, {
//     onSuccess: () => queryClient.invalidateQueries("users"),
//   });

//   const updateMutation = useMutation(
//     (data: User) => updateUser(data.id, data),
//     {
//       onSuccess: () => queryClient.invalidateQueries("users"),
//     }
//   );

//   const onSubmit = (data: User) => {
//     if (user) {
//       updateMutation.mutate({ ...data, id: user.id });
//     } else {
//       createMutation.mutate(data);
//     }
//     onClose();
//   };

//   return (
//     <form onSubmit={handleSubmit(onSubmit)}>
//       <div>
//         <label>Name</label>
//         <input {...register("name")} />
//       </div>
//       <div>
//         <label>Email</label>
//         <input {...register("email")} />
//       </div>
//       <button type="submit">{user ? "Update" : "Create"}</button>
//     </form>
//   );
// };

// export default CreateEditForm;

import React from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQueryClient } from "react-query";
import { createUser, updateUser, User } from "../api/Users";

interface FormProps {
  user?: User | null;
  onClose: () => void;
}

const CreateEditForm: React.FC<FormProps> = ({ user, onClose }) => {
  const { register, handleSubmit, reset } = useForm<User>({
    defaultValues: user || { name: "", email: "" },
  });

  const queryClient = useQueryClient();

  // Create user mutation
  const createMutation = useMutation(createUser, {
    onSuccess: (newUser) => {
      // Directly update the cache
      queryClient.setQueryData<User[]>("users", (oldData) =>
        oldData ? [...oldData, newUser] : [newUser]
      );
    },
  });

  // Update user mutation

  const updateMutation = useMutation(
    (data: User) => updateUser(data.id, data),
    {
      onSuccess: (updatedUser) => {
        // Safely handle undefined `oldData`
        queryClient.setQueryData<User[]>("users", (oldData) =>
          oldData
            ? oldData.map((u) => (u.id === updatedUser.id ? updatedUser : u))
            : []
        );
      },
    }
  );

  const onSubmit = (data: User) => {
    if (user) {
      updateMutation.mutate({ ...data, id: user.id });
    } else {
      createMutation.mutate(data);
    }
    reset(); // Reset form
    onClose(); // Close modal
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div>
        <label>Name</label>
        <input {...register("name")} required />
      </div>
      <div>
        <label>Email</label>
        <input {...register("email")} required />
      </div>
      <button type="submit">{user ? "Update" : "Create"}</button>
    </form>
  );
};

export default CreateEditForm;
